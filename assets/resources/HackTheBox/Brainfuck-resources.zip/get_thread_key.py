#! /usr/bin/env python3
import string

kwnon_plaintext = 'Hackingforfunandprofit'
cryptogram = 'Jkoijegnbwzwxmlegrwsnn'
key = []

for cryptogram_letter, kwnon_plaintext_letter in zip(cryptogram.lower(), kwnon_plaintext.lower()):
	# Kn = Cn - Pn mod 26
	key_letter_num = (string.ascii_lowercase.find(cryptogram_letter) - string.ascii_lowercase.find(kwnon_plaintext_letter)) % 26
	key.append(string.ascii_lowercase[key_letter_num])

key = ''.join(key)
print(f'Key --> {key}')
