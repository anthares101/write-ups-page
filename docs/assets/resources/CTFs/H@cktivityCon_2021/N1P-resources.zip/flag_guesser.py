#!/usr/bin/env python3

from pwn import *

connection = remote('challenge.ctf.games',31921)

def get_guess_fitness(encrypted_flag: str, guessed_flag: str):
	mathing_characters = 0
	for encrypted_flag_character, guessed_flag_character in zip(encrypted_flag, guessed_flag):
		if(encrypted_flag_character == guessed_flag_character):
			mathing_characters +=  1
		else:
			break

	return mathing_characters / len(encrypted_flag)
	

with log.progress('Getting encrypted flag...') as p:
	connection.recvline('NINA: Hello! I found a flag, look!')
	encrypted_flag = connection.recvline().decode().strip()

with log.progress('Guessing flag...') as p:
	flag_guess = ''
	current_fitness = 0;
	alphabet = list(string.printable)[:-6]

	while current_fitness != 1:
		new_character = ''

		for character in alphabet:
			p.status(flag_guess + character)
			connection.recv()
			connection.send(flag_guess + character)
			connection.recvline("""connection.recvline('NINA: Ta-daaa!! I think this is called a 'one' 'time' 'pad' or something?')""")

			encrypted_guess = connection.recvline().decode().strip()
			new_fitness = get_guess_fitness(encrypted_flag, encrypted_guess)
			if(new_fitness > current_fitness):
				new_character = character
				current_fitness = new_fitness

		flag_guess += new_character

	p.success(flag_guess)

connection.close()
