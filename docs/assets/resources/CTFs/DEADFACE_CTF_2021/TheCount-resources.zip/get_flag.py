#! /usr/bin/env python3

from pwn import *
import string


alphabet = string.ascii_lowercase

challenge = remote('code.deadface.io', 50000)
challenge.recvuntil('Your word is: ')
word = challenge.recv().decode().strip()

print(f'The word is --> {word}')
word_sum = 0
for letter in word:
	word_sum += alphabet.find(letter)
print(f'Its value is --> {word_sum}')

challenge.send(str(word_sum))
flag = challenge.recv().decode().strip()
print(f'Flag --> {flag}')

challenge.close()
